import { Component } from '@angular/core';

@Component({
  selector: 'app-skills',
  imports: [],
  standalone: true,
  templateUrl: './skills.html',
  styleUrl: './skills.css'
})
export class SkillsComponent {

}
