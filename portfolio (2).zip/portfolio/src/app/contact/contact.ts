import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-contact',
  imports: [],
  standalone: true,
  templateUrl: './contact.html',
  styleUrl: './contact.css'
})
export class ContactComponent {

}
