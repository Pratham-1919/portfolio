import { Component } from '@angular/core';

@Component({
  selector: 'app-projects',
  imports: [],
  standalone: true,
  templateUrl: './projects.html',
  styleUrl: './projects.css'
})
export class ProjectsComponent {

}
